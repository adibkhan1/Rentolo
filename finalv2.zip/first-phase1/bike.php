<?php

$servername = "localhost";
$userName = "root";
$password = "";
$dbname = "myrent_db";

// Create connection
$conn = new mysqli($servername, $userName, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

include 'header.php';

echo '<!--== Page Title Area Start ==-->';
echo '<section id="page-title-area" class="section-padding overlay">';
echo '<div class="container">';
echo '<div class="row">';
echo '<!-- Page Title Start -->';
echo '<div class="col-lg-12">';
echo '<div class="section-title  text-center">';
echo '<h2>Our Bikes</h2>';
echo '<span class="title-line"><i class="fa fa-car"></i></span>';
echo '<p>There is a list of options available for you to choose from</p>';
echo '</div>';
echo '</div>';
echo '<!-- Page Title End -->';
echo '</div>';
echo '</div>';
echo '</section>';
echo '<!--== Page Title Area End ==-->';
echo '';
echo '<!--== Car List Area Start ==-->';
echo '<section id="car-list-area" class="section-padding">';
echo '<div class="container">';
echo '<div class="row">';
echo '<!-- Car List Content Start -->';
echo '<div class="col-lg-8">';
echo '<div class="car-list-content">';
echo '<!-- Single Car Start -->';

$r = mysqli_query($conn, "SELECT * FROM bikes "); // using mysqli_query instead

while ($res = mysqli_fetch_array($r)) {
    echo '<div class="single-car-wrap">';
    echo '<div class="row">';
    echo '<!-- Single Car Thumbnail -->';
    echo '<div class="col-lg-5">';
    echo '<div class="car-list-thumb bike-thumb-1"></div>';
    echo '</div>';
    echo '<!-- Single Car Info -->';
    echo '<div class="col-lg-7">';
    echo '<div class="display-table">';
    echo '<div class="display-table-cell">';
    echo '<div class="car-list-info">';
    echo '<h2><a href="#">' . $res['bikename'] . '</a></h2>';
    echo '<h5>RM' . $res['Rent'] . ' Rent /per a day</h5>';
    echo '<ul class="car-info-list">';
    echo '<li>Good Condition</li>';
    echo '</ul>';
    echo '<p class="rating">';
    echo '<i class="fa fa-star"></i>';
    echo '<i class="fa fa-star"></i>';
    echo '<i class="fa fa-star"></i>';
    echo '<i class="fa fa-star"></i>';
    echo '<i class="fa fa-star unmark"></i>';
    echo '</p>';
    echo '<a href="booking-bike.php?bike=' . $res['bikename'] . '" class="rent-btn">Book It</a>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '<!-- Single Car info -->';
    echo '</div>';
    echo '</div>';
    echo '<!-- Single Car End -->';
}

echo '';
echo '</div>';
echo '</div>';
echo '<!-- Car List Content End -->';
echo '</div>';
echo '</div>';
echo '</section>';
echo '<!--== Car List Area End ==-->';

include 'footer.php';
