<?php
$ID = $_GET['ID'];

//including the database connection file
$servername = "localhost";
$userName = "root";
$password = "";
$dbname = "myrent_db";

//Create connection
$conn = new mysqli($servername, $userName, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}




//getting id of the data from url


//deleting the row from table$sql = "INSERT INTO user (FirstName, LastName, Email, username, password, Admin) VALUES ('$firstname','$lastname','$email','$username','$password', '0')";
$query = "SELECT * FROM `pendingVehicle` WHERE ID='$ID'";
$result = $conn->query($query);
$row = $result->fetch_assoc();

$vehicleName = $row["vehicleName"];
$type = $row["type"];
$rent = $row["rent"];

if ($row["vehicleType"] == 'car') {
    $sql = "INSERT INTO `cars` (`carname`, `Type`, `Rent`)
VALUES('$vehicleName','$type','$rent')";

    if (mysqli_query($conn, $sql)) {
        header("Location:admin.php");
    } else {
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
    }
}
else if ($row["vehicleType"] == 'bike') {
    $sql = "INSERT INTO `bikes` (`bikename`, `Type`, `Rent`)
VALUES('$vehicleName','$type','$rent')";

    if (mysqli_query($conn, $sql)) {
        header("Location:admin.php");
    } else {
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
    }
}
else if ($row["vehicleType"] == 'bicycle') {
    $sql = "INSERT INTO `bicycles` (`bicyclename`, `Type`, `Rent`)
VALUES('$vehicleName','$type','$rent')";

    if (mysqli_query($conn, $sql)) {
        header("Location:admin.php");
    } else {
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
    }
}
else if ($row["vehicleType"] == 'lorry') {
    $sql = "INSERT INTO `lorries` (`lorryname`, `Type`, `Rent`)
VALUES('$vehicleName','$type','$rent')";

    if (mysqli_query($conn, $sql)) {
        header("Location:admin.php");
    } else {
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
    }
}

$sql = "DELETE FROM pendingVehicle WHERE ID=$ID";
mysqli_query($conn, $sql)
?>
