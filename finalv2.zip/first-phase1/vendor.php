<?php

include 'header.php';

$verified = $_SESSION['verified'];

echo '<!--== Page Title Area Start ==-->';
echo '<section id="page-title-area" class="section-padding overlay">';
echo '<div class="container">';
echo '<div class="row">';
echo '<!-- Page Title Start -->';
echo '<div class="col-lg-12">';
echo '<div class="section-title  text-center">';
echo '<h2>Vendor Page</h2>';
echo '<span class="title-line"><i class="fa fa-car"></i></span>';
echo '<p>There is a list of vehicles you can add.</p>';
echo '</div>';
echo '</div>';
echo '<!-- Page Title End -->';
echo '</div>';
echo '</div>';
echo '</section>';
echo '<!--== Page Title Area End ==-->';

if ($verified == 0) {
    echo '<section id="service-page-wrapper" class="section-padding">';
    echo '<div class="section-title  text-center">';
    echo '<h3>Account is not yet verified</h3>';
    echo '</div>';
    echo "</section>\n";
} else {
    echo '<section id="service-page-wrapper" class="section-padding" style="width: 500px; margin: auto">';
    echo '<div class="section-title  text-center">';
    echo '<h3>ADD Vehicle</h3>';
    echo '<span class="title-line"><i class="fa fa-car"></i></span>';
    echo '';
    echo '</div>';
    echo '';
    echo '<form action="pendingVehicle.php" method="post">';
    echo '<div class="form-group">';
    echo '<label for="vehicleName">Vehicle Name</label>';
    echo '<input type="text" class="form-control" name="vehicleName">';
    echo '</div>';
    echo '<div class="form-group">';
    echo '<label for="type">Class</label>';
    echo '<input type="text" class="form-control" name="type">';
    echo '</div>';
    echo '<div class="form-group">';
    echo '<label for="rent">Rent</label>';
    echo '<input type="text" class="form-control" name="rent">';
    echo '</div>';
    echo '<div class="form-group">';
    echo '<label for="vehicleType">Choose vehicle type:</label>';
    echo '<select name="vehicleType" id="vehicleType">';
    echo '<option value="car">Car</option>';
    echo '<option value="bike">Bike</option>';
    echo '<option value="bicycle">Bicycle</option>';
    echo '<option value="lorry">Lorry</option>';
    echo '</select>';
    echo '</div>';
    echo '';
    echo '<button type="submit" class="btn btn-default" name="submit">ADD</button>';
    echo '</form>';
    echo "    </section>\n";
}

include 'footer.php';
