<?php
session_start();

$servername = "localhost";
$userName = "root";
$password = "";
$dbname = "myrent_db";

// Create connection
$conn = new mysqli($servername, $userName, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<?php
include 'header.php';
$username = $_SESSION['username'];
$bikeSelect = "";

if (isset($_GET['bike'])) {
    $bikeSelect = $_GET['bike'];
}


?>
<!--== Slider Area Start ==-->
<section id="home-slider-area">
    <div class="home-slider-item slider-bg-1 overlay">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="slideshowcontent">
                        <h1>BOOK A BIKE TODAY!</h1>
                        <p>FOR AS LOW AS RM100 A DAY PLUS 15% DISCOUNT <br> FOR OUR RETURNING CUSTOMERS</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="home-slider-item slider-bg-2 overlay">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="slideshowcontent">
                        <h1>SAVE YOUR MONEY</h1>
                        <p>FOR AS LOW AS RM100 A DAY PLUS 15% DISCOUNT <br> FOR OUR RETURNING CUSTOMERS</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="home-slider-item slider-bg-3 overlay">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="slideshowcontent">
                        <h1>ENJOY YOUR JOURNEY</h1>
                        <p>FOR AS LOW AS RM100 A DAY PLUS 15% DISCOUNT <br> FOR OUR RETURNING CUSTOMERS</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--== Slider Area End ==-->
<?php

// Book A Car Area Start ==-->
echo '<div id="book-a-car">';
echo '  <div class="container">';
echo '  <div class="row">';
echo '        <div class="col-lg-12">';
echo '              <div class="booka-car-content">';
echo '  <div class="booka-car-content">';
echo '<form method="post" action="Payment.php?id=' . urlencode($username) . '">';
echo  '<div class="pick-location bookinput-item">';
echo  '<select class="custom-select" name="location">';
echo  '<option selected>PickUp Location</option>';
echo    '<option value="Skudai">Skudai</option>';
echo      '<option value="Senai">Senai</option>';
echo  '<option value="Johor Bahru">Johor Bahru</option>';
echo    '<option value="Tampoi">Tampoi</option>';
echo    '</select>';
echo  '</div>';

echo    '<div class="bookinput-item">';
echo        '<input type="date" placeholder="PickUp Date" name="pick_date" style="color:black; padding:5px"/>';
echo      '</div>';

echo    '<div class="bookinput-item">';
echo          '<input type="date" placeholder="Return Date" name="return_date" style="color:black; padding:5px"/>';
echo  '</div>';

echo      '<div class="car-choose bookinput-item" >';
echo        '<select class="custom-select" name="bike_type">';

if ($bikeSelect != "") {
    echo '<option selected>' . $bikeSelect . '</option>';
} else {
    echo              '<option selected>Choose Bike</option>';

    $r = mysqli_query($conn, "SELECT * FROM bikes "); // using mysqli_query instead

    while ($res = mysqli_fetch_array($r)) {
        echo "<option value=$res[bikename]>" . $res['bikename'] . "</option>";
    }
}
echo                        '</select>';
echo                            '</div>';
echo '<div class="bookcar-btn bookinput-item">';
if ($username) {
    echo '<button type="submit" name="bookBike">Book Bike</button>';
} else {
    echo '<a href=\"register.php\">login First!</a>';
}
echo      '</div>';
echo      '</form>';
echo      '</div>';
echo      '</div>';
echo      '</div>';
echo      '</div>';
echo  '</div>';
?>
<!--== Book A Car Area End ==-->

<?php
include 'footer.php';
?>