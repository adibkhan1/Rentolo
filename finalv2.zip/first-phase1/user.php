<?php
$servername = "localhost";
$userName = "root";
$password = "";
$dbname = "myrent_db";

// Create connection
$conn = new mysqli($servername, $userName, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

include 'header.php';

$username = $_SESSION['username'];
$admin = $_SESSION['admin'];
$verified = $_SESSION['verified'];

echo '<!--== Page Title Area Start ==-->';
echo '<section id="page-title-area" class="section-padding overlay">';
echo '<div class="container">';
echo '<div class="row">';
echo '<!-- Profile Title Start -->';
echo '<div class="col-lg-12">';
echo '<div class="section-title  text-center">';
echo "<h2>$username</h2>";
echo '<img style="width:20%;" src="assets/img/profile.png" alt="JSOFT">';
echo '<div><br>';
echo '<span class="title-line"><i class="fa fa-car"></i></span>';
echo '';
echo '</div>';
echo '';
echo '<br>';
echo '<br>';
echo '<div class="btn-group">';
echo '';
echo '';
echo '<button type="button" onclick="location.href=\'editprof.php?id=' . $userName . '\'" class="btn btn-secondary">Edit Profile</button>';
echo '</div>';
echo '</div>';
echo '<!-- Page Title End -->';
echo '</div>';
echo '</div>';
echo '</section>';
echo '<!--== Page Title Area End ==-->';
echo '';
echo '<!--== About Page Content Start ==-->';
echo '<section id="about-area" class="section-padding">';
echo '<div class="container">';
echo '<div class="col">';
echo '<!-- Section Title Start -->';
echo '<!----Here supposed to start php for the registered info---->';
echo '';
if ($verified == 0) {
    echo '<div class="section-title  text-center">';
    echo '<h3>Account is not yet verified</h3>';
    echo '</div>';
}
echo '<div class="section-title  text-center">';
echo '<h3>Profile Info</h3>';
echo '<span class="title-line"><i class="fa fa-car"></i></span>';
echo '';
echo '</div>';
echo '';

$username = $_SESSION['username'];
$query = "SELECT * FROM `user` WHERE username='$username'";
$result = $conn->query($query);
while ($row = $result->fetch_assoc()) {
    echo "<label><strong>Firstname: </strong></label>" . " " . $row["Firstname"] . "<br>";
    echo "<label><strong>Lastname: </strong></label>" . " " . $row["Lastname"] . "<br>";
    echo "<label><strong>Phone Number: </strong></label>" . " " . $row["pnum"] . "<br>";
    echo "<label><strong>Email: </strong></label>" . " " . $row["Email"] . "<br>";
}


echo '</div>';
echo '</section>';
echo '<!-- Section Title End -->';
echo '</div>';

if ($admin == 0 && $verified == 1) {

    echo '<!--== About Page Content Start ==-->';
    echo '<section id="about-area" class="section-padding">';
    echo '<div class="container">';
    echo '<div class="col">';
    echo '<!-- Section Title Start -->';
    echo '<!----Here supposed to start php for the registered info---->';
    echo '';
    echo '<div class="section-title  text-center">';
    echo '<h3>Booked Car</h3>';
    echo '<span class="title-line"><i class="fa fa-car"></i></span>';
    echo '';
    echo '</div>';
    echo '<div class="table">';
    echo '<table width="100%" border="0">';
    echo '<tr bg-color=\'#CCCCCC\'>';
    echo '<td><label><strong>Location</strong></label></td>';
    echo '<td><label><strong>Pick Date</strong></label></td>';
    echo '<td><label><strong>Return Date</strong></label></td>';
    echo '<td><label><strong>Car</strong></label></td>';
    echo '</tr>';


    $username = $_SESSION['username'];


    $result = mysqli_query($conn, "SELECT * FROM booking WHERE username='$username'"); // using mysqli_query instead

    while ($res = mysqli_fetch_array($result)) {
        echo "<tr>";

        echo "<td>" . $res['location'] . "</td>";
        echo "<td>" . $res['pickdate'] . "</td>";
        echo "<td>" . $res['returndate'] . "</td>";
        echo "<td>" . $res['car'] . "</td>";
    }

    echo '</table>';
    echo '</div>';
    echo '</div>';

    echo '<br /><br />';

    echo '<div class="col">';
    echo '<!-- Section Title Start -->';
    echo '<!----Here supposed to start php for the registered info---->';
    echo '';
    echo '<div class="section-title  text-center">';
    echo '<h3>Booked Bike</h3>';
    echo '<span class="title-line"><i class="fa fa-car"></i></span>';
    echo '';
    echo '</div>';
    echo '<div class="table">';
    echo '<table width="100%" border="0">';
    echo '<tr bg-color=\'#CCCCCC\'>';
    echo '<td><label><strong>Location</strong></label></td>';
    echo '<td><label><strong>Pick Date</strong></label></td>';
    echo '<td><label><strong>Return Date</strong></label></td>';
    echo '<td><label><strong>Bike</strong></label></td>';
    echo '</tr>';


    $username = $_SESSION['username'];


    $result = mysqli_query($conn, "SELECT * FROM bookingBike WHERE username='$username'"); // using mysqli_query instead

    while ($res = mysqli_fetch_array($result)) {
        echo "<tr>";

        echo "<td>" . $res['location'] . "</td>";
        echo "<td>" . $res['pickdate'] . "</td>";
        echo "<td>" . $res['returndate'] . "</td>";
        echo "<td>" . $res['bike'] . "</td>";
    }

    echo '</table>';
    echo '</div>';
    echo '</div>';

    echo '<br /><br />';

    echo '<div class="col">';
    echo '<!-- Section Title Start -->';
    echo '<!----Here supposed to start php for the registered info---->';
    echo '';
    echo '<div class="section-title  text-center">';
    echo '<h3>Booked Bicycle</h3>';
    echo '<span class="title-line"><i class="fa fa-car"></i></span>';
    echo '';
    echo '</div>';
    echo '<div class="table">';
    echo '<table width="100%" border="0">';
    echo '<tr bg-color=\'#CCCCCC\'>';
    echo '<td><label><strong>Location</strong></label></td>';
    echo '<td><label><strong>Pick Date</strong></label></td>';
    echo '<td><label><strong>Return Date</strong></label></td>';
    echo '<td><label><strong>Bicycle</strong></label></td>';
    echo '</tr>';


    $username = $_SESSION['username'];


    $result = mysqli_query($conn, "SELECT * FROM bookingBicycle WHERE username='$username'"); // using mysqli_query instead

    while ($res = mysqli_fetch_array($result)) {
        echo "<tr>";

        echo "<td>" . $res['location'] . "</td>";
        echo "<td>" . $res['pickdate'] . "</td>";
        echo "<td>" . $res['returndate'] . "</td>";
        echo "<td>" . $res['bicycle'] . "</td>";
    }

    echo '</table>';
    echo '</div>';
    echo '</div>';

    echo '<br /><br />';

    echo '<div class="col">';
    echo '<!-- Section Title Start -->';
    echo '<!----Here supposed to start php for the registered info---->';
    echo '';
    echo '<div class="section-title  text-center">';
    echo '<h3>Booked Lorry</h3>';
    echo '<span class="title-line"><i class="fa fa-car"></i></span>';
    echo '';
    echo '</div>';
    echo '<div class="table">';
    echo '<table width="100%" border="0">';
    echo '<tr bg-color=\'#CCCCCC\'>';
    echo '<td><label><strong>Location</strong></label></td>';
    echo '<td><label><strong>Pick Date</strong></label></td>';
    echo '<td><label><strong>Return Date</strong></label></td>';
    echo '<td><label><strong>Lorry</strong></label></td>';
    echo '</tr>';


    $username = $_SESSION['username'];


    $result = mysqli_query($conn, "SELECT * FROM bookingLorry WHERE username='$username'"); // using mysqli_query instead

    while ($res = mysqli_fetch_array($result)) {
        echo "<tr>";

        echo "<td>" . $res['location'] . "</td>";
        echo "<td>" . $res['pickdate'] . "</td>";
        echo "<td>" . $res['returndate'] . "</td>";
        echo "<td>" . $res['lorry'] . "</td>";
    }

    echo '</table>';
    echo '</div>';
    echo '</div>';

    echo '<br /><br />';

    echo '';
    echo '<!-- Section Title End -->';
    echo '</div>';
    echo '</section>';
}



include 'footer.php';
