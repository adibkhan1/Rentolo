<?php //Connect to DB
include 'carrental.php';
?>

<?php
include 'header.php';

echo '<!--== Page Title Area Start ==-->';
echo '<section id="page-title-area" class="section-padding overlay">';
echo '<div class="container">';
echo '<div class="row">';
echo '<!-- Page Title Start -->';
echo '<div class="col-lg-12">';
echo '<div class="section-title  text-center">';
echo '<h2>Login</h2>';
echo '<span class="title-line"><i class="fa fa-car"></i></span>';
echo '<p>Welcome to our page.</p>';
echo '</div>';
echo '</div>';
echo '<!-- Page Title End -->';
echo '</div>';
echo '</div>';
echo '</section>';
echo '<!--== Page Title Area End ==-->';

echo '<section id="lgoin-page-wrap" class="section-padding">';
echo '<div class="container">';
echo '<div class="row">';
echo '<div class="col-lg-4 col-md-8 m-auto">';
echo '<div class="login-page-content">';
echo '<div class="login-form">';
echo '<h3>Welcome!</h3>';
echo '<form action="welcome.php" method="post">';
echo '<div class="username">';
echo '<input type="text" name="username" placeholder="Email or Username" required>';
echo '</div>';
echo '<div class="password">';
echo '<input type="password" name="password" placeholder="Password" required>';
echo '</div>';
echo '<div class="log-btn">';
echo '<button type="submit" name="loginSubmit"><i class="fa fa-sign-in"></i> Log In</button>';
echo '</div>';
echo '</form>';
echo '</div>';
echo '<div class="create-ac">';
echo '<p>Forgot Password? <a href="Forget.php"> Reset Password</a></p>';
echo '<p>Don\'t have an account? <a href="register.php">Sign Up</a></p>';
echo '</div>';
echo '</div>';
echo '</div>';
echo '</div>';
echo '</div>';
echo '</section>';

include 'footer.php';
?>
