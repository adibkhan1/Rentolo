<?php

session_start();
if (!isset($_SESSION["admin"])) {
    $_SESSION["admin"] = 99;
    $_SESSION["verified"] = 99;
}

$username = $_SESSION['username'];
$admin = $_SESSION['admin'];
$verified = $_SESSION['verified'];

echo "<!DOCTYPE html>\n";
echo "<html class=\"no-js\" lang=\"zxx\">\n";
echo "\n";
echo "<head>\n";
echo "    <meta charset=\"utf-8\">\n";
echo "    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\n";
echo "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n";
echo "    <!--=== Favicon ===-->\n";
echo "    <link rel=\"shortcut icon\" href=\"favicon.ico\" type=\"image/x-icon\" />\n";
echo "\n";
echo "    <title>Rentolo</title>\n";
echo "\n";
echo "    <!--=== Bootstrap CSS ===-->\n";
echo "    <link href=\"assets/css/bootstrap.min.css\" rel=\"stylesheet\">\n";
echo "    <!--=== Animate CSS ===-->\n";
echo "    <link href=\"assets/css/plugins/animate.css\" rel=\"stylesheet\">\n";
echo "    <!--=== Vegas Min CSS ===-->\n";
echo "    <link href=\"assets/css/plugins/vegas.min.css\" rel=\"stylesheet\">\n";
echo "    <!--=== Slicknav CSS ===-->\n";
echo "    <link href=\"assets/css/plugins/slicknav.min.css\" rel=\"stylesheet\">\n";
echo "    <!--=== Magnific Popup CSS ===-->\n";
echo "    <link href=\"assets/css/plugins/magnific-popup.css\" rel=\"stylesheet\">\n";
echo "    <!--=== Owl Carousel CSS ===-->\n";
echo "    <link href=\"assets/css/plugins/owl.carousel.min.css\" rel=\"stylesheet\">\n";
echo "    <!--=== Gijgo CSS ===-->\n";
echo "    <link href=\"assets/css/plugins/gijgo.css\" rel=\"stylesheet\">\n";
echo "    <!--=== FontAwesome CSS ===-->\n";
echo "    <link href=\"assets/css/font-awesome.css\" rel=\"stylesheet\">\n";
echo "    <!--=== Theme Reset CSS ===-->\n";
echo "    <link href=\"assets/css/reset.css\" rel=\"stylesheet\">\n";
echo "    <!--=== Main Style CSS ===-->\n";
echo "    <link href=\"style.css\" rel=\"stylesheet\">\n";
echo "    <!--=== Responsive CSS ===-->\n";
echo "    <link href=\"assets/css/responsive.css\" rel=\"stylesheet\">\n";
echo "\n";
echo "\n";
echo "    <!--[if lt IE 9]>\n";
echo "        <script src=\"//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js\"></script>\n";
echo "        <script src=\"//oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>\n";
echo "    <![endif]-->\n";
echo "</head>\n";
echo "\n";
echo "<body class=\"loader-active\">\n";
echo "\n";
echo "    <!--== Preloader Area Start ==-->\n";
echo "    <div class=\"preloader\">\n";
echo "        <div class=\"preloader-spinner\">\n";
echo "            <div class=\"loader-content\">\n";
echo "                <img src=\"assets/img/preloader.gif\" alt=\"JSOFT\">\n";
echo "            </div>\n";
echo "        </div>\n";
echo "    </div>\n";
echo "    <!--== Preloader Area End ==-->\n";
echo "\n";
echo "    <!--== Header Area Start ==-->\n";
echo "    <header id=\"header-area\" class=\"fixed-top\">\n";
echo "        <!--== Header Top Start ==-->\n";
echo "        <div id=\"header-top\" class=\"d-none d-xl-block\">\n";
echo "            <div class=\"container\">\n";
echo "                <div class=\"row\">\n";
echo "                    <!--== Single HeaderTop Start ==-->\n";
echo "                    <div class=\"col-lg-3 text-left\">\n";
echo "                        <i class=\"fa fa-map-marker\"></i> Skudai, Johor Bahru, Malaysia\n";
echo "                    </div>\n";
echo "                    <!--== Single HeaderTop End ==-->\n";
echo "\n";
echo "                    <!--== Single HeaderTop Start ==-->\n";
echo "                    <div class=\"col-lg-3 text-center\">\n";
echo "                        <i class=\"fa fa-mobile\"></i> +60 0123456789\n";
echo "                    </div>\n";
echo "                    <!--== Single HeaderTop End ==-->\n";
echo "\n";
echo "                    <!--== Single HeaderTop Start ==-->\n";
echo "                    <div class=\"col-lg-3 text-center\">\n";
echo "                        <i class=\"fa fa-clock-o\"></i>Weekdays 09.00 - 17.00 Weekends 09.00 - 15.30\n";
echo "                    </div>\n";
echo "                    <!--== Single HeaderTop End ==-->\n";
echo "\n";
echo "                    <!--== Social Icons Start ==-->\n";
echo "                    <div class=\"col-lg-3 text-right\">\n";
echo "                        <div class=\"header-social-icons\">\n";
echo "                            <a href=\"#\"><i class=\"fa fa-behance\"></i></a>\n";
echo "                            <a href=\"#\"><i class=\"fa fa-pinterest\"></i></a>\n";
echo "                            <a href=\"#\"><i class=\"fa fa-facebook\"></i></a>\n";
echo "                            <a href=\"#\"><i class=\"fa fa-linkedin\"></i></a>\n";
echo "                        </div>\n";
echo "                    </div>\n";
echo "                    <!--== Social Icons End ==-->\n";
echo "                </div>\n";
echo "            </div>\n";
echo "        </div>\n";
echo "        <!--== Header Top End ==-->\n";
echo "\n";
echo "        <!--== Header Bottom Start ==-->\n";
echo "        <div id=\"header-bottom\">\n";
echo "            <div class=\"container\">\n";
echo "                <div class=\"row\">\n";
echo "                    <!--== Logo Start ==-->\n";
echo "                    <div class=\"col-lg-4\">\n";
echo "                        <a href=\"index.php\" class=\"logo\">\n";
echo "                            <img src=\"assets/img/logo.png\" alt=\"JSOFT\">\n";
echo "                        </a>\n";
echo "                    </div>\n";
echo "                    <!--== Logo End ==-->\n";
echo "\n";
echo "                    <!--== Main Menu Start ==-->\n";
echo "                    <div class=\"col-lg-8 d-none d-xl-block\">\n";
echo "                        <nav class=\"mainmenu alignright\">\n";
echo "                            <ul>\n";
echo "                                <li><a href=\"index.php\">Home</a></li>\n";
if ($admin == 0 && $verified == 1) {
    echo "                                <li><a href=\"services.php\">Services</a>\n";
    echo "                                    <ul>\n";
    echo "                                        <li><a href=\"car-right-sidebar.php\">Car Rental</a></li>\n";
    echo "                                        <li><a href=\"bike.php\">Bike Rental</a></li>\n";
    echo "                                        <li><a href=\"bicycle.php\">Bicycle Rental</a></li>\n";
    echo "                                        <li><a href=\"lorry.php\">Lorry Service</a></li>\n";
    echo "                                    </ul>\n";
    echo "                                </li>\n";
}
if ($username) {
    if ($admin == 1)
        echo "<li><a href=\"admin.php\">Account</a></li>";
    else
        echo "<li><a href=\"user.php\">Account</a></li>";

    if ($admin == 0 && $verified == 1) {
        echo "<li><a href=\"allbooking.php\">Booking</a></li>";
    }
    echo "<li><a href=\"logout.php\">Log Out</a></li>";
} else {
    echo "<li><a href=\"login.php\">Log In</a></li>";
    echo "<li><a href=\"register.php\">Register</a></li>";
}
echo "\n";
echo "                            </ul>\n";
echo "                        </nav>\n";
echo "                    </div>\n";
echo "                    <!--== Main Menu End ==-->\n";
echo "                </div>\n";
echo "            </div>\n";
echo "        </div>\n";
echo "        <!--== Header Bottom End ==-->\n";
echo "    </header>\n";
echo "    <!--== Header Area End ==-->\n";
echo "\n";
