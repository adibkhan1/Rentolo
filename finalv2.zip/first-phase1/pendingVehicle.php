<?php
$servername = "localhost";
$userName = "root";
$password = "";
$dbname = "myrent_db";

// Create connection
$conn = new mysqli($servername, $userName, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}




if ( isset( $_POST['submit'] ) )

{
$vehicleName =  mysqli_real_escape_string($conn, $_POST['vehicleName']);
$type =  mysqli_real_escape_string($conn, $_POST['type']);
$rent =  mysqli_real_escape_string($conn, $_POST['rent']);
$vehicleType =  mysqli_real_escape_string($conn, $_POST['vehicleType']);

$sql="INSERT INTO `pendingVehicle` (`vehicleName`, `type`, `rent`, `vehicleType`)
VALUES('$vehicleName','$type','$rent','$vehicleType')";

if(mysqli_query($conn, $sql)){
     header("Location:vendor.php");
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}


}



?>