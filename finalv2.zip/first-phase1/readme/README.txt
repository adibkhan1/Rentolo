WELCOME TO MyRent-AL!

UPLOAD THE myrent_db.sql IN FOLDER NAMED sql TO LOCALHOST

Open Homepage.html

User: 
username: 001	
password: 1234

Admin:
username: 111	
password: 1234